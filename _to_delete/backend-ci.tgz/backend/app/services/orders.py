"""주문 금액 계산 (API명세서 v1.3 · 1.5).

라우트가 아니라 여기에 두는 이유:
    항목 추가·수정·삭제, 회원 연결·해제, 수동 할인, 결제 —
    6개 엔드포인트가 전부 "항목이 바뀌면 주문 금액을 다시 쓴다"는 같은 일을 한다.
    라우트마다 복사해두면 한 곳만 고치고 나머지를 놓친다.

DB 접근을 섞지 않은 이유:
    이 모듈은 Supabase를 import하지 않는다. 순수 함수라 테스트에서 DB 없이 검증된다.
    금액은 틀리면 곧바로 사고인 영역이라 테스트 가능성을 최우선으로 둔다.
"""

from dataclasses import dataclass
from decimal import ROUND_FLOOR, Decimal

import structlog

logger = structlog.get_logger("app.services.orders")

# 명세서 4.5 PATCH items - "quantity는 1~99"
MIN_ITEM_QUANTITY = 1
MAX_ITEM_QUANTITY = 99


def money(value: object) -> int:
    """DECIMAL(10,2) 값을 API용 정수 금액으로 바꾼다 (명세서 1.2 "금액은 정수 JSON number").

    Supabase는 DECIMAL을 문자열 또는 float으로 돌려준다. 둘 다 받아야 하므로
    float()을 한 번 거친다. routes/orders.py의 _shape()가 이미 쓰던 방식과 동일하다.
    """
    return int(round(float(value)))  # type: ignore[arg-type]


def _floor_rate(amount: int, rate: Decimal | float | str) -> int:
    """금액 × 비율을 내림한 정수 (명세서 1.5가 floor를 명시).

    현재 등급 비율(0.0100 · 0.0050)에서는 float으로 계산해도 결과가 같다. 다만 비율이
    바뀌면 조용히 어긋난다. 예: rate=0.0029, amount=10000 이면 float은 28.999999999999996이라
    내림 시 28, Decimal은 29다. 등급 비율은 운영 중 조정될 수 있는 값이므로 그때마다
    안전성을 다시 증명하지 않아도 되게 Decimal로 고정한다.

    str(rate)를 거치는 이유:
        Decimal(0.0029)는 float의 오차를 그대로 물려받아 0.002899999...가 된다.
        Decimal(str(0.0029))만이 0.0029다. Supabase가 DECIMAL 컬럼을 float으로
        돌려주는 경우가 있어 Decimal로 감싸는 것만으로는 부족하다.
    """
    return int((Decimal(amount) * Decimal(str(rate))).to_integral_value(rounding=ROUND_FLOOR))


@dataclass(frozen=True)
class Amounts:
    """orders 행에 그대로 써넣을 금액 6종.

    frozen=True인 이유: 계산 결과를 나중에 손대는 코드가 생기면 어디서 바뀌었는지
    추적이 불가능해진다. 다시 계산하게 강제한다.
    """

    gross_amount: int
    membership_discount_amount: int
    manual_discount_amount: int
    discount_amount: int
    total_amount: int
    point_earned: int

    def as_order_columns(self) -> dict[str, int]:
        """orders 테이블 UPDATE에 그대로 넘길 dict.

        컬럼명 매핑을 라우트마다 손으로 쓰면 오타 하나로 금액이 안 반영된다.
        여기서 한 번만 정의한다.
        """
        return {
            "gross_amount": self.gross_amount,
            "membership_discount_amount": self.membership_discount_amount,
            "manual_discount_amount": self.manual_discount_amount,
            "discount_amount": self.discount_amount,
            "total_amount": self.total_amount,
            "point_earned": self.point_earned,
        }


def line_subtotal(quantity: int, unit_price: int) -> int:
    """항목 1줄의 소계. order_item.subtotal에 저장한다.

    한 줄짜리 함수를 굳이 만든 이유: subtotal을 계산하는 지점이 항목 추가·수량 변경·
    상품 재선택 3곳인데, 한 곳에서 quantity * unit_price를 빠뜨려도 눈에 안 띈다.
    """
    return quantity * unit_price


def compute_amounts(
    items: list[dict],
    *,
    discount_rate: Decimal | float | str = Decimal("0"),
    point_earn_rate: Decimal | float | str = Decimal("0"),
    manual_discount_amount: int = 0,
) -> Amounts:
    """항목 목록에서 주문 금액 전부를 다시 계산한다 (명세서 1.5).

        gross_amount               = Σ(quantity × unit_price)
        membership_discount_amount = floor(gross × grade.discount_rate)
        discount_amount            = membership + manual
        total_amount               = gross − discount
        point_earned               = floor(total × grade.point_earn_rate)

    items는 quantity·unit_price 키만 있으면 되는 dict 목록이다. Supabase 응답 행을
    그대로 넘겨도 되고 테스트에서 손으로 만든 dict를 넘겨도 된다. 특정 타입에
    묶지 않으려고 일부러 dict로 받는다.

    키워드 전용(*) 으로 받는 이유: discount_rate와 point_earn_rate는 둘 다 Decimal
    비율이라 위치 인자로 두면 순서가 바뀌어도 조용히 통과한다. 호출부에서 이름을
    쓰도록 강제한다.
    """
    # 증분(gross += ...)이 아니라 매번 전체 SUM이다. PostgREST에 트랜잭션이 없어
    # 항목 쓰기와 금액 쓰기 사이에서 실패할 수 있는데, 전체 재계산이면 다음 요청이
    # 스스로 바로잡는다. 증분이면 한 번 틀어진 값이 영구히 남는다.
    gross = sum(int(item["quantity"]) * money(item["unit_price"]) for item in items)

    membership = _floor_rate(gross, discount_rate)
    manual = manual_discount_amount

    # 항목이 줄어 gross가 기존 수동 할인보다 작아질 수 있다.
    # (예: 500원 할인을 걸어둔 뒤 마지막 항목을 삭제 -> gross 300, manual 500)
    # 명세서는 이 경우를 정의하지 않는다. 삭제를 400으로 막으면 직원이 빠져나갈 방법이
    # 없어지므로 할인을 gross에 맞춰 깎고 경고 로그를 남긴다.
    # 직원이 금액을 직접 넣는 POST /discount 쪽은 라우트가 미리 검사해 400을 준다 -
    # 그쪽은 입력 오류이지 여기처럼 파생된 결과가 아니기 때문이다.
    if membership + manual > gross:
        clamped = max(0, gross - membership)
        logger.warning(
            "order.manual_discount_clamped",
            gross_amount=gross,
            membership_discount_amount=membership,
            requested_manual=manual,
            applied_manual=clamped,
        )
        manual = clamped

    discount = membership + manual
    total = gross - discount

    return Amounts(
        gross_amount=gross,
        membership_discount_amount=membership,
        manual_discount_amount=manual,
        discount_amount=discount,
        total_amount=total,
        # 적립은 할인 후 실제 결제액 기준이다. gross 기준으로 잡으면 할인받고
        # 적립까지 더 받는 구조가 되어 명세서 1.5와 어긋난다.
        point_earned=_floor_rate(total, point_earn_rate),
    )
