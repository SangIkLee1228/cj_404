"""주문 금액 계산 검증 (API명세서 v1.3 · 1.5).

이 파일은 DB도 앱도 띄우지 않는다. compute_amounts가 순수 함수라서 가능하다.
다른 테스트들이 "토큰 없으면 401"만 확인하는 것과 달리, 여기서는 실제 계산 결과를 본다.
"""

import math
from decimal import Decimal

from app.services.orders import Amounts, compute_amounts, line_subtotal, money

# 명세서 4.5 GET /orders/{id} 예시에 실제로 실린 등급 비율
FAMILY_DISCOUNT_RATE = Decimal("0.0100")
POINT_EARN_RATE = Decimal("0.0050")  # 전 등급 단일 0.5% (명세서 6장 FE 확정사항)


def test_money_accepts_both_string_and_float():
    # Supabase는 DECIMAL을 문자열로도 float으로도 돌려준다. 둘 다 통과해야 한다.
    assert money("2200.00") == 2200
    assert money(2200.0) == 2200


def test_line_subtotal():
    assert line_subtotal(quantity=3, unit_price=2200) == 6600


def test_gross_is_sum_of_lines():
    items = [
        {"quantity": 1, "unit_price": "3200.00"},
        {"quantity": 2, "unit_price": "2200.00"},
        {"quantity": 1, "unit_price": "3500.00"},
    ]
    amounts = compute_amounts(items)
    assert amounts.gross_amount == 11100
    # 회원을 붙이지 않았으니 할인도 적립도 0이고, total은 gross와 같아야 한다.
    assert amounts.discount_amount == 0
    assert amounts.total_amount == 11100
    assert amounts.point_earned == 0


def test_matches_spec_example_exactly():
    """명세서 4.5의 예시 응답 숫자를 그대로 재현한다.

    gross 11100 -> 1% 할인 111 -> total 10989 -> 0.5% 적립 54.
    적립이 54인 것이 중요하다. 10989 * 0.005 = 54.945 이므로 반올림이면 55가 되고,
    명세서가 지정한 floor여야 54가 된다.
    """
    items = [{"quantity": 1, "unit_price": "11100.00"}]
    amounts = compute_amounts(
        items,
        discount_rate=FAMILY_DISCOUNT_RATE,
        point_earn_rate=POINT_EARN_RATE,
    )
    assert amounts == Amounts(
        gross_amount=11100,
        membership_discount_amount=111,
        manual_discount_amount=0,
        discount_amount=111,
        total_amount=10989,
        point_earned=54,
    )


def test_decimal_holds_at_rates_where_float_floor_breaks():
    """현재 비율(1%·0.5%)에서는 float도 같은 답을 낸다. 비율이 바뀌면 달라진다.

    rate=0.0029, gross=10000 -> float은 28.999999999999996이라 내림 시 28,
    Decimal은 29. 등급 비율이 조정되는 순간 조용히 1이 어긋나는 지점을 고정해둔다.
    """
    assert math.floor(10000 * 0.0029) == 28  # float의 실제 동작
    amounts = compute_amounts(
        [{"quantity": 1, "unit_price": 10000}], discount_rate=Decimal("0.0029")
    )
    assert amounts.membership_discount_amount == 29


def test_float_rate_does_not_leak_its_error_into_decimal():
    """Supabase가 비율을 float으로 돌려줘도 결과가 같아야 한다.

    Decimal(0.0029)는 float 오차를 물려받아 0.002899999...가 된다.
    _floor_rate가 str()을 거치지 않으면 이 테스트가 28로 떨어진다.
    """
    assert compute_amounts(
        [{"quantity": 1, "unit_price": 10000}], discount_rate=0.0029
    ).membership_discount_amount == 29


def test_point_is_earned_on_total_not_gross():
    # 할인 후 금액 기준이어야 한다. gross 기준이면 할인받고 적립까지 더 받는 구조가 된다.
    amounts = compute_amounts(
        [{"quantity": 1, "unit_price": 10000}],
        discount_rate=Decimal("0.0100"),
        point_earn_rate=POINT_EARN_RATE,
    )
    assert amounts.total_amount == 9900
    assert amounts.point_earned == 49  # floor(9900 * 0.005) = 49, gross 기준이면 50


def test_manual_discount_is_added_to_membership_discount():
    amounts = compute_amounts(
        [{"quantity": 1, "unit_price": 10000}],
        discount_rate=Decimal("0.0100"),
        manual_discount_amount=500,
    )
    assert amounts.membership_discount_amount == 100
    assert amounts.manual_discount_amount == 500
    assert amounts.discount_amount == 600
    assert amounts.total_amount == 9400


def test_manual_discount_is_clamped_when_items_shrink_below_it():
    """500원 할인을 걸어둔 주문에서 항목이 줄어 gross가 300이 된 상황.

    total이 음수가 되면 orders 행 저장이 거부되므로 할인을 깎아서 0으로 맞춘다.
    """
    amounts = compute_amounts(
        [{"quantity": 1, "unit_price": 300}], manual_discount_amount=500
    )
    assert amounts.manual_discount_amount == 300
    assert amounts.total_amount == 0


def test_empty_order_is_all_zero():
    # 항목을 전부 지운 PENDING 주문. 0으로 떨어져야 다음 계산이 정상 시작된다.
    amounts = compute_amounts([], discount_rate=FAMILY_DISCOUNT_RATE)
    assert amounts.gross_amount == 0
    assert amounts.total_amount == 0


def test_as_order_columns_covers_every_amount_column():
    amounts = compute_amounts([{"quantity": 2, "unit_price": 1500}])
    assert amounts.as_order_columns() == {
        "gross_amount": 3000,
        "membership_discount_amount": 0,
        "manual_discount_amount": 0,
        "discount_amount": 0,
        "total_amount": 3000,
        "point_earned": 0,
    }
