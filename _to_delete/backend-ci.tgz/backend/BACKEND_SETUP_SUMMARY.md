# 백엔드 기본 세팅 요약 (v2 — 스냅빵/BreadEye 기준 재세팅)

**이전 세팅은 이 저장소에 남아있던 이전 프로젝트("차량 손상 검수") 흔적을 그대로 반영한
것이었습니다.** Notion의 "뚜레쥬르 요구사항 명세서 v1.0"과 "스냅빵_DB설계서_v1.2"(16개
테이블, 6개 도메인)를 전체 정독하고, 실제 프로젝트 주제(CJ푸드빌 뚜레쥬르 — Vision AI 기반
빵 인식·계산·재고 운영 최적화 시스템, 가칭 스냅빵/브레드아이)에 맞춰 백엔드를 다시 세팅했습니다.
차량(vehicles)/파손이력(damage_history) 관련 코드는 전부 제거했습니다.

> 이 문서는 크게 두 부분입니다: **① 지금까지 뭘 했는지**(변경 이력, 아래) / **② 앞으로 뭘 해야
> 하는지**(FastAPI 첫 프로젝트용 상세 가이드, [여기로 바로가기](#다음-단계--fastapi가-처음이신-분을-위한-상세-가이드)).

## 이번에 새로 반영한 것

| 스택               | 반영 내용                                                                                                    |
| ------------------ | ------------------------------------------------------------------------------------------------------------- |
| DB 스키마          | `backend/app/schemas/`에 16개 테이블 전체를 pydantic 모델로 옮김 (코드값은 Literal 타입으로 강제)             |
| RESTful API        | 실제 도메인 라우트 4종: `products`(FR-16), `scan-sessions`(FR-01/02), `inventory`(FR-13), `notifications`(FR-15) |
| Swagger UI          | `/docs` → **`/api/docs`로 이동** (팀 Docker/Nginx 가이드 확인: nginx가 `/api/*`만 프록시하므로 루트 `/docs`는 nginx 경유 시 404) |
| 로깅                | `python-json-logger` → **structlog로 교체** (팀 Notion "StructLog" 페이지 컨벤션: `_common`/`_context`/이벤트 로그 3단 구조, `{도메인}.{동작}` 이벤트명, trace_id 전파) |
| GPU 추론 연동 지점 | `/api/inference/predict`(범용) → **`/api/scan-sessions/{id}/recognize`로 재설계** (SCAN_SESSION/DETECTED_ITEM 흐름에 맞춤, 여전히 501 stub) |

## 제거된 것

- `backend/app/api/routes/items.py`, `inference.py` (이전 프로젝트용 범용 예시) → `products.py`, `scan_sessions.py`로 대체
- `backend/app/models/`(빈 디렉터리) → `backend/app/schemas/`로 대체
- README/CI/nginx 주석 등에 남아있던 "차량", "damage", "cj-x-vision-backend" 등의 문구
- 저장소 루트에 잘못 커밋되어 있던 `snapbbang-branding-no-nginx.patch`(작업용 잔여 파일 — 이미 병합된 커밋을 다시 파일로 내보내둔 것이라 필요 없음)

## 새 파일

```
backend/app/schemas/
  codes.py           # 코드값 Literal 타입 (STAFF_ACCOUNT.role, ORDERS.status 등 6장 코드표 전체)
  common.py          # Store, StaffAccount, Member, MembershipGrade, Product(+Create)
  scan.py            # ScanSession(+Create), DetectedItem, CorrectionLog
  orders.py          # Order, OrderItem, PointTransaction
  inventory.py       # Inventory
  notifications.py   # Notification, SalesStatDaily, DemographicStat
  system.py          # ModelVersion

backend/app/api/routes/
  products.py        # GET/POST /api/products (FR-16, PRODUCT 테이블)
  scan_sessions.py    # POST /api/scan-sessions, POST /api/scan-sessions/{id}/recognize (stub)
  inventory.py        # GET /api/inventory (FR-13)
  notifications.py    # GET /api/notifications, PATCH /api/notifications/{id}/read (FR-15)

backend/tests/
  test_products.py, test_scan_sessions.py   # 401 인증 검증
  test_schemas.py                            # 16개 테이블 스키마 스모크 테스트
```

## 수정된 파일

```
backend/app/main.py         # 앱 title/description을 스냅빵으로, docs_url을 /api/docs로, structlog 미들웨어
backend/app/api/router.py   # products/scan_sessions/inventory/notifications 라우터 등록
backend/app/core/logging.py # structlog 설정 (팀 컨벤션 반영)
backend/app/api/routes/storage.py  # 예시 문구를 damage-history → scan_session/product 이미지로 수정
backend/requirements.txt    # python-json-logger → structlog
.github/workflows/backend-ci.yml   # 이미지 태그 cj-x-vision-backend → snapbbang-backend
nginx/nginx.conf, docker-compose.yml  # 주석 문구 수정 (damage-photo → tray-scan photo, /docs → /api/docs)
README.md                   # 제목/설명/기술스택/디렉터리구조/현재범위 전면 갱신
```

## 검증

로컬 venv에 `requirements-dev.txt`를 새로 설치해 처음부터 다시 확인했습니다.

- `ruff check .` → 통과
- `pytest` → **10 passed** (health, `/api/me` 401×2, products 401×2, scan-sessions 401×2, 16개 테이블 스키마 인스턴스화 3건)
- 서버 기동 후 확인: `/health` 200, **`/api/docs` 200 / 루트 `/docs` 404**(의도된 이동), `/api/products` 401(무토큰), `/metrics` 200
- `/api/openapi.json` 경로 목록이 `/api/products`, `/api/scan-sessions`, `/api/scan-sessions/{id}/recognize`, `/api/inventory`, `/api/notifications*`, `/api/me`, `/api/storage/*`, `/health`로 정확히 잡힘
- structlog 출력 실제 확인: `{"event": "http.request_completed", "trace_id": "...", "service": "snapbbang-backend", "env": "development", "timestamp": "...Z", ...}` — 팀 컨벤션의 `_common` 자동 주입 필드 정상 동작
- 다른 팀원/세션과의 병합(README를 유저플로우·UX 문서 기준으로 확장한 브랜치)도 충돌 없이 합쳐졌고, 병합 후에도 위 검증을 다시 통과했습니다.

---

# 다음 단계 — FastAPI가 처음이신 분을 위한 상세 가이드

FastAPI로 실제 프로젝트를 하는 게 처음이라고 하셨으니, "뭘 해야 하는지"뿐 아니라 "왜/어떻게"까지
같이 적었습니다. 순서대로 따라오시면 됩니다.

## 0. 지금 정확히 뭐가 있고, 뭐가 없는지부터

**있는 것**
- FastAPI 앱 골격 (`backend/app/main.py`), JWT 토큰 검증(`core/security.py`), 이미지 업로드(`storage.py`)
- 예시 라우트 4개(`products`, `scan-sessions`, `inventory`, `notifications`) — 전부 "이렇게
  짜면 된다"는 견본이지, 실제 서비스 로직(결제, 재고 차감 등)은 아직 없습니다.
- DB 설계서의 16개 테이블을 그대로 옮긴 Python 타입 정의(`backend/app/schemas/`)

**없는 것 (제일 중요, 다음 단계의 출발점)**
- ⚠️ **Supabase 프로젝트 안에 실제 테이블이 하나도 없습니다.** `backend/app/schemas/`는
  "테이블이 이렇게 생겼으면 좋겠다"를 Python 코드로 옮겨놓은 설계도일 뿐, Supabase의 Postgres에
  `CREATE TABLE`을 실행한 적은 아직 없습니다. **지금 서버를 켜고 `/api/products`를 호출하면,
  Supabase 쪽에 `product` 테이블이 없어서 에러가 납니다.** 이게 다음 단계 1순위입니다(2번 항목).
- 주문 생성 → 결제 → 재고 차감 → 알림 생성으로 이어지는 실제 비즈니스 로직
- AI 인식 모델 연동 (`scan-sessions/{id}/recognize`는 지금 501만 반환)
- 직원 로그인(`STAFF_ACCOUNT`)과 Supabase Auth를 연결하는 매핑

## 1단계 — 일단 켜서 눌러보기 (개념 잡기, ~20분)

먼저 손으로 만져보는 게 제일 빠릅니다.

```bash
cd backend
pip install -r requirements-dev.txt
uvicorn app.main:app --reload
```

브라우저로 `http://localhost:8000/api/docs`를 열어보세요. 이게 **Swagger UI**입니다 — 코드를
한 줄도 안 짜고, 이 화면에서 버튼만 눌러서 API를 테스트해볼 수 있는 자동 생성 문서입니다.
FastAPI는 라우트를 짜기만 하면 이 화면을 알아서 만들어줍니다(그래서 "자동 문서화"라고 부릅니다).

- 화면에 `products`, `scan`, `inventory`, `notifications` 같은 태그로 라우트들이 묶여
  있을 겁니다. 아무 라우트나 펼쳐서 "Try it out" → "Execute"를 눌러보세요.
- 지금은 실제 DB 테이블이 없어서 대부분 에러가 날 겁니다 — 정상입니다, 2단계를 하면 됩니다.
- 우측 상단 "Authorize" 버튼은 JWT 토큰을 넣는 곳입니다. `products`/`scan-sessions` 같은
  라우트들은 `Depends(get_current_user)`가 걸려 있어서, 토큰 없이 호출하면 401(인증 실패)이
  돌아옵니다 — `backend/tests/test_products.py`가 바로 이 401 동작을 검증하는 테스트입니다.
- `http://localhost:8000/health`, `http://localhost:8000/metrics`도 열어보세요 — 각각
  "서버가 살아있는지 확인용", "모니터링 도구가 긁어가는 숫자 지표용" 엔드포인트입니다.

## 2단계 — Supabase에 실제 테이블 만들기 (가장 먼저 해야 할 실질적 작업)

Supabase 프로젝트 대시보드 → 왼쪽 메뉴 **SQL Editor** → 아래 SQL을 그대로 붙여넣고 실행하면,
DB설계서의 "1차(필수)" 9개 테이블이 만들어집니다. FR-01~FR-16의 핵심 흐름(스캔 → 인식 →
결제 → 재고 → 알림)을 돌리는 데 필요한 최소 세트입니다.

```sql
create table store (
  store_id bigint generated always as identity primary key,
  store_name varchar(100) not null,
  store_code varchar(20) not null unique,
  address varchar(200),
  phone varchar(20),
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table staff_account (
  staff_id bigint generated always as identity primary key,
  store_id bigint not null references store(store_id),
  login_id varchar(50) not null unique,
  password_hash varchar(255) not null,
  name varchar(50) not null,
  role varchar(20) not null default 'STAFF',
  phone varchar(20),
  is_active boolean not null default true,
  last_login_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table product (
  product_id bigint generated always as identity primary key,
  store_id bigint not null references store(store_id),
  product_name varchar(100) not null,
  category varchar(50),
  price decimal(10,2) not null,
  image_url varchar(255),
  ai_class_label varchar(100),
  source_type varchar(20) not null,
  stock_baseline_pct smallint default 5,
  is_active boolean not null default true,
  created_by bigint references staff_account(staff_id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table scan_session (
  scan_session_id bigint generated always as identity primary key,
  store_id bigint not null references store(store_id),
  staff_id bigint not null references staff_account(staff_id),
  image_url varchar(255),
  status varchar(20) not null default 'CAPTURED',
  overlap_warning boolean not null default false,
  recognition_ms int,
  failure_reason varchar(200),
  started_at timestamptz not null default now(),
  completed_at timestamptz
);

create table detected_item (
  detected_item_id bigint generated always as identity primary key,
  scan_session_id bigint not null references scan_session(scan_session_id),
  product_id bigint references product(product_id),
  ai_class_label varchar(100) not null,
  confidence decimal(5,2) not null,
  bbox_x decimal(6,4),
  bbox_y decimal(6,4),
  bbox_w decimal(6,4),
  bbox_h decimal(6,4),
  quantity smallint not null default 1,
  is_below_threshold boolean not null default false,
  created_at timestamptz not null default now()
);

create table orders (
  order_id bigint generated always as identity primary key,
  store_id bigint not null references store(store_id),
  scan_session_id bigint references scan_session(scan_session_id),
  staff_id bigint not null references staff_account(staff_id),
  member_id bigint,
  applied_grade_id bigint,
  status varchar(20) not null default 'PENDING',
  payment_method varchar(20),
  total_amount decimal(10,2) not null default 0,
  discount_amount decimal(10,2) not null default 0,
  membership_discount_amount decimal(10,2) not null default 0,
  manual_discount_amount decimal(10,2) not null default 0,
  manual_discount_reason varchar(200),
  manual_discount_staff_id bigint references staff_account(staff_id),
  point_used int not null default 0,
  point_earned int not null default 0,
  ordered_at timestamptz not null default now(),
  paid_at timestamptz
);

create table order_item (
  order_item_id bigint generated always as identity primary key,
  order_id bigint not null references orders(order_id),
  product_id bigint not null references product(product_id),
  quantity smallint not null default 1,
  unit_price decimal(10,2) not null,
  subtotal decimal(10,2) not null,
  source_type varchar(15) not null
);

create table inventory (
  inventory_id bigint generated always as identity primary key,
  store_id bigint not null references store(store_id),
  product_id bigint not null references product(product_id),
  produced_qty int not null default 0,
  sold_qty int not null default 0,
  remaining_qty int not null default 0,
  updated_at timestamptz not null default now(),
  unique (store_id, product_id)
);

create table notification (
  notification_id bigint generated always as identity primary key,
  store_id bigint not null references store(store_id),
  notif_type varchar(20) not null,
  related_product_id bigint references product(product_id),
  remaining_qty_snapshot int,
  title varchar(100) not null,
  message varchar(300) not null,
  is_read boolean not null default false,
  read_at timestamptz,
  is_deleted boolean not null default false,
  deleted_at timestamptz,
  created_at timestamptz not null default now()
);
```

몇 가지 참고할 점:
- **테이블명은 전부 소문자**입니다 (`product`, `scan_session`). DB설계서 문서에는 `PRODUCT`처럼
  대문자로 적혀 있지만, 그건 문서상의 표기 관례일 뿐 실제 설계 원칙은 "snake_case"입니다
  (설계서 1.3절). `backend/app/api/routes/products.py` 등도 이미 소문자 테이블명
  (`supabase.table("product")`)으로 짜여 있으니 그대로 맞춰서 만들면 됩니다.
- `member`, `membership_grade`, `correction_log`, `point_transaction`, `sales_stat_daily`,
  `demographic_stat`, `model_version` (DB설계서의 2차/3차 테이블 7개)은 지금 당장 안 만들어도
  1차 흐름은 돌아갑니다. 필요해지면 `backend/app/schemas/`의 해당 파일(예: `orders.py`의
  `PointTransaction`)을 보고 같은 패턴으로 SQL을 추가하면 됩니다.
- 이 SQL을 실행한 뒤에는 저장소에 마이그레이션 파일로 남겨두는 걸 추천합니다(지금은 이
  README에만 있는 상태). 예를 들어 `backend/migrations/0001_init.sql`처럼 파일로 저장해서
  git에 커밋해두면, 나중에 다른 팀원이 새 Supabase 프로젝트를 만들 때도 그대로 재현할 수
  있습니다. (지금 저장소에는 이 폴더가 없습니다 — 팀과 상의해서 만드는 걸 권장.)
- **RLS(Row Level Security)**는 당장 안 켜도 됩니다. 백엔드가 `service_role` 키로 접속하는데,
  이 키는 RLS를 무시하고 전체 테이블에 접근할 수 있는 관리자 키이기 때문입니다
  (`backend/app/core/supabase_client.py` 참고). 나중에 프론트엔드가 Supabase에 직접
  접근하는 경로가 생기면 그때 RLS 정책을 켜는 걸 고려하세요.

테이블을 만들고 나서, `.env` 파일에 실제 Supabase 값이 채워져 있는 상태로 서버를 다시 켜고
`/api/docs`에서 `POST /api/products`를 눌러보세요 — Authorize에 실제 JWT를 넣으면 정상적으로
빵 하나가 등록될 겁니다. (Supabase Auth로 로그인해서 토큰을 받는 법은 프론트엔드의 로그인
화면을 한 번 써보면 제일 빠릅니다 — 로그인 후 브라우저 개발자도구 Network 탭에서 요청 헤더의
`Authorization: Bearer ...` 값을 복사해 Swagger에 붙여넣으면 됩니다.)

## 3단계 — 라우트 하나를 직접 따라 만들어보기 (배우는 목적)

FastAPI 라우트가 어떻게 짜여 있는지, `backend/app/api/routes/products.py`를 예로 뜯어보겠습니다.

```python
@router.get("")
def list_products(store_id: int | None = None, user: CurrentUser = Depends(get_current_user)):
    supabase = get_supabase()
    query = supabase.table("product").select("*").eq("is_active", True)
    if store_id is not None:
        query = query.eq("store_id", store_id)
    result = query.execute()
    return result.data
```

- `@router.get("")`: "GET 요청이 오면 이 함수를 실행해라"는 뜻. `router`에 이미
  `prefix="/products"`가 붙어 있어서(파일 상단 `APIRouter(prefix="/products", ...)`),
  최종 경로는 `/api/products`가 됩니다.
- `store_id: int | None = None`: 쿼리 파라미터(`?store_id=1` 같은 것). FastAPI가 타입만
  보고 알아서 검증·변환해줍니다 — 문자열 `"abc"`를 넣으면 자동으로 422 에러를 돌려줍니다.
- `Depends(get_current_user)`: "이 함수를 실행하기 전에 `get_current_user`를 먼저 실행해서
  결과를 `user`에 넣어줘"라는 뜻. `get_current_user`(`core/security.py`)는 JWT를 검증하고
  실패하면 401을 던집니다 — 그래서 라우트 본문에는 인증 실패 처리 코드를 따로 안 써도 됩니다.
  이게 FastAPI의 "의존성 주입(Dependency Injection)" 패턴입니다.
- `return result.data`: 파이썬 dict/list를 그냥 리턴하면 FastAPI가 알아서 JSON으로
  바꿔줍니다.

**POST 쪽(`create_product`)은 pydantic 모델**(`ProductCreate`, `backend/app/schemas/common.py`)을
파라미터로 받습니다. 요청 body의 JSON이 이 모델의 필드와 안 맞으면(타입이 다르거나 필수
필드가 빠지면) FastAPI가 라우트 코드를 실행하기도 전에 자동으로 422 에러와 함께 "뭐가
잘못됐는지" 알려줍니다. 이게 pydantic을 쓰는 핵심 이유입니다 — 입력값 검증을 직접 안 짜도 됩니다.

**연습 삼아 해볼 것**: `backend/app/schemas/orders.py`에 이미 `Order` 모델이 있으니, 이걸
활용해서 `GET /api/orders` (주문 목록 조회, `orders` 테이블 조회) 라우트를 `products.py`와
똑같은 패턴으로 직접 만들어보세요. 막히면 `inventory.py`(가장 짧고 단순한 예시)를 참고하면
됩니다.

## 4단계 — 팀 미해결 이슈, 이 순서로 푸는 걸 추천

`BACKEND_SETUP_SUMMARY.md`의 "팀이 확정해야 할 것" 항목들 중, 아래 순서로 처리하는 걸
추천합니다 — 1번이 나머지 라우트 설계에 전부 영향을 주기 때문입니다.

1. **STAFF_ACCOUNT ↔ Supabase Auth 매핑** — 먼저 결정. 가장 간단한 방법은
   `staff_account` 테이블에 `auth_user_id uuid` 컬럼을 추가하고, 직원이 Supabase Auth로
   로그인할 때 이 값을 채워두는 것입니다. 그러면 `get_current_user`가 돌려주는
   `user.id`(Supabase Auth UUID)로 `staff_account`를 조회해서 `staff_id`/`store_id`를
   자동으로 알아낼 수 있고, `products`/`scan-sessions` 라우트에서 지금처럼 `store_id`를
   요청 바디로 직접 받을 필요가 없어집니다. (단, README에 적힌 대로 실제 설계는 PIN 로그인
   방식(S-00)이라, Supabase Auth email/password를 그대로 쓸지부터 팀 결정이 필요합니다.)
2. **API 명세서**가 나오면 그에 맞춰 주문 생성(결제 → 재고 차감 → 알림 생성) 트랜잭션
   로직을 추가.
3. **멤버십 등급 수치**(할인율/적립률), `ORDERS.membership_discount_amount` 계산 방식의
   문서 모순을 기획팀에 확인.

## 5단계 — 테스트 작성법 (pytest 처음이신 경우)

`backend/tests/`에 이미 예시가 있습니다. 실행은 이렇게:

```bash
cd backend
pytest          # 전체 테스트 실행
pytest -v       # 어떤 테스트가 통과/실패했는지 자세히
```

- `test_health.py`: 가장 단순한 예시 — `/health`를 호출해서 응답이 기대한 값인지 확인.
- `test_products.py`, `test_scan_sessions.py`: 토큰 없이 호출하면 401이 나오는지 확인.
  이런 "인증 안 하면 막히는지" 테스트는 라우트를 새로 추가할 때마다 같이 만드는 습관을
  들이면 좋습니다 — Supabase 네트워크 호출까지 안 가고도(즉, 진짜 DB 연결 없이도) 인증
  로직만 빠르게 검증할 수 있기 때문입니다.
- `test_schemas.py`: pydantic 모델이 유효한지 확인하는 "스모크 테스트"(가장 기본적인
  동작만 확인하는 가벼운 테스트).
- `conftest.py`: pytest가 자동으로 제일 먼저 읽는 파일. 여기서 `SUPABASE_URL` 등 필수
  환경변수에 더미 값을 채워둡니다 — 안 그러면 앱을 import하는 순간(`Settings()`가 실행되는
  시점) 에러가 나기 때문입니다.

## 6단계 — 막힐 때 체크리스트

- **`pydantic_core._pydantic_core.ValidationError` 같은 에러로 서버가 아예 안 켜짐** →
  `.env` 파일에 `SUPABASE_URL`/`SUPABASE_SERVICE_ROLE_KEY`/`SUPABASE_JWT_SECRET`이 실제로
  채워져 있는지 확인(`backend/.env.example` 참고, `cp backend/.env.example backend/.env`
  후 값 채우기).
- **계속 401만 뜸** → Swagger의 "Authorize"에 넣은 값이 진짜 JWT인지(Supabase Auth 로그인
  후 받은 `access_token`), `Authorization: Bearer <토큰>` 형식이 맞는지 확인.
- **500 에러 + Supabase 관련 메시지** → 대부분 "그 테이블이 Supabase에 없음" 또는
  "컬럼명이 다름"입니다. 2단계에서 만든 테이블명/컬럼명이 라우트 코드의
  `supabase.table("...")` 문자열과 정확히 일치하는지(대소문자 포함) 확인.
- **`ruff check .`에서 에러** → 대부분 import 순서/줄바꿈 문제라 `ruff check --fix .`로
  자동 수정됩니다. 자동 수정이 안 되는 건 메시지에 어떤 규칙(예: `E501` 줄 길이)을
  위반했는지 나오니 그걸 보고 고치면 됩니다.
- **pytest 실패** → 어떤 테스트인지(`test_...` 함수명)와 `assert` 줄의 기대값 vs 실제값을
  먼저 보세요. `pytest -v --tb=short`로 실행하면 에러 위치를 더 짧게 볼 수 있습니다.

## 추천 순서 요약 (체크리스트)

- [ ] `/api/docs` 열어서 라우트 구조 눈으로 확인 (1단계)
- [ ] Supabase에 1차 필수 테이블 9개 생성 (2단계)
- [ ] `.env` 채우고 `POST /api/products` 실제로 성공시켜보기
- [ ] `products.py`를 참고해서 `GET /api/orders` 직접 만들어보기 (3단계, 학습용)
- [ ] STAFF_ACCOUNT ↔ Supabase Auth 매핑 팀과 논의/결정 (4단계, 최우선 이슈)
- [ ] 새 라우트 추가할 때마다 401 테스트 습관화 (5단계)
- [ ] API 명세서 나오면 주문 생성(결제→재고차감→알림) 로직 라우트 추가

---

## 팀이 확정해야 할 것 (코드로 임의 결정하지 않음)

1. **STAFF_ACCOUNT(BIGINT) ↔ Supabase Auth 사용자(UUID) 매핑이 아직 없습니다.** 그래서
   `products`/`scan-sessions` 생성 라우트는 `store_id`/`staff_id`를 JWT에서 유도하지 않고
   요청 바디로 직접 받습니다. 매핑 컬럼(예: `STAFF_ACCOUNT.auth_user_id UUID`)이 정해지면
   `get_current_user`를 확장해 자동으로 채우도록 바꿔야 합니다. (위 "4단계" 참고)
2. **`ORDERS.membership_discount_amount`의 DB설계서 "기본값" 칸(`total_amount*0.5`)이 본문
   설명(등급별 `discount_rate`로 계산)과 모순됩니다** — DB설계서 팀에 확인 필요 (오탈자로 추정).
3. **API 명세서가 아직 없습니다** (2026-08-20 기준, 팀 스프린트 백로그의 8/21 예정 작업). 주문
   생성(결제→재고차감→알림생성) 같은 트랜잭션 로직은 API 스펙이 나온 뒤 구현하는 게 맞다고
   판단해 이번 세팅에는 포함하지 않았습니다.
4. **CJ ONE 포인트 적립률**이 요구사항 명세서(0.5%/제휴시 0.1%)와 목업 설명서(0.1% 고정) 간에
   불일치합니다 — `MEMBERSHIP_GRADE`로 스키마는 대비돼 있으나 실제 수치는 기획 확정 필요.
5. **보안**: Notion 스프린트 백로그 페이지에 Supabase `service_role` 키와 JWT secret이 평문으로
   박혀 있습니다. `backend/.env`의 키와 동일하다면(확인 결과 동일함) **키 재발급 + Notion에서
   평문 삭제를 권장**합니다 — 코드로 해결할 문제가 아니라 팀 조치가 필요합니다.

## 실행 방법 (변경 없음)

```bash
docker compose up --build          # 로컬 개발 (핫리로드)
cd backend && pip install -r requirements-dev.txt && uvicorn app.main:app --reload
pytest && ruff check .
```
